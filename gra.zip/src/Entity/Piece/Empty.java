package Entity.Piece;

import App.Board;
import Entity.Entity;
import Interfaces.IMoves;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class Empty extends Piece {

    public Empty(int rank, String file){
        super(rank, file);
    }

    @Override
    public ArrayList<Integer> getPossibleMoves(Board board){
        return super.getPossibleMoves(board);
    }

}
