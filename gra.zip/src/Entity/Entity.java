package Entity;

import Interfaces.IHashMaps;

abstract public class Entity implements IHashMaps {

    public int getRank() {
        return rank;
    }
    public String getFile() {
        return file;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public void setFile(String file) {
        this.file = file;
    }

    protected int rank;
    protected String file;

    protected Entity(int rank, String file){
        this.rank = rank;
        this.file = file;
    }
}
