import App.App;

public class Main {
    public static void main(String[] args){
        App app = new App();
        app.repaint();

        //App app2 = new App();
//        String startposition = "b/qbk/n1b1n/r5r/ppppppppp/11/5P5/4P1P4/3P1B1P3/2P2B2P2/1PRNQBKNRP1";
//        Board board = new Board(startposition);
//        for (int i = 0; i < 11; i++){
//            for (int j = 0; j < 11; j++){
//                try{
//                    System.out.print(board.board.get(i*11+j).getPiece() + "\t");
//                } catch (Exception e){
//                    System.out.print(null + "\t");
//                }
//
//            }
//            System.out.print("\n");
//        }

    }
}